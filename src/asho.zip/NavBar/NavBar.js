import React from 'react'
import { Link } from 'react-router-dom';
import { useState, useEffect } from 'react'
const Navbar = () => {
    const[state, setState] = useState({navbar_content:"white",color:"black"});
    const changeBackground = () => {
       
        const newColor = state.navbar_content == "white" ? " " : "white";
        const textnewColor = state.navbar_content == "white" ? " " : "black";
        setState({ navbar_content: newColor ,color:textnewColor});
      };
    useEffect(()=>{
       
        document.addEventListener("scroll",()=>{
            const backgroundcolor = window.scrollY > 0 ? "white" : "white";
            const color = window.scrollY > 0 ? "black" : "black";
            setState({navbar_content:backgroundcolor,color:color});
        });
    },[state.navbar_content]);
    return (
        <div id="nav-bar" >
        <nav className="navbar navbar-expand-lg fixed-top navbar_content mb-5" id="myScrollspy"  style={{ backgroundColor: `${state.navbar_content}`}}>
            <div className="container">
                <Link className="navbar-brand" to="/">
                    <img type="logo" className="img-fluid logo_img" src="images/ProHireeLogo.png"
                        style={{background: 'transparent'},{ height:'50px'},{ width:'70px'}} alt="" />
                </Link>
                <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav"
                    aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation"
                    onClick={changeBackground}>
                    <i className="fa fa-bars text-white"></i>
                </button>
                <div className="collapse navbar-collapse" id="navbarNav" >
                    <ul className="navbar-nav ">
                        <li className="nav-item">
                            <Link className="nav-link font-weight-bold" style={{color:state.color}} id="a1" to="/">HOME</Link>
                        </li>
                        <li className="nav-item dropdown position-relative d-inline-block">
                            <a className="nav-link dropdown-toggle  font-weight-bold" href="#" id="a2" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style={{color:state.color}}> 
                                FOR CANDIDATES
                            </a>
                            <div className="dropdown-menu dropdown-content d-none position-absolute ml-4 bg-white rounded"
                                aria-labelledby="a2">
                                <Link className="dropdown-item" to="/myprofile">My
                                    Profile</Link>
                                <Link className="dropdown-item" to="/myresume">My
                                    Resume</Link>
                                <Link className="dropdown-item"
                                    to="appliedjobs">Applied
                                    Job</Link>
                                <Link className="dropdown-item"
                                    to="/jobalerts">Job
                                    Alerts</Link>
                                <Link className="dropdown-item "
                                    to="/savedjobs">Saved
                                    Jobs</Link>
                                {/* <!-- <a className="dropdown-item"
                                    href="././Company/candidate_profile/cv manager/cv_manager.html">CV
                                    Manager</a> --> */}
                                <Link className="dropdown-item"
                                    to="/changepassword">Change
                                    Password</Link>
                            </div>
                        </li>
                        <li className="nav-item dropdown position-relative d-inline-block">
                            <a className="nav-link dropdown-toggle  font-weight-bold" href="#" id="a3" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style={{color:state.color}}>
                                FOR EMPLOYERS
                            </a>
                            <div className="dropdown-menu dropdown-content  d-none position-absolute ml-4 bg-white rounded"
                                aria-labelledby="navbarDropdown">
                                <Link className="dropdown-item" to="/company_profile">Company
                                    Profile</Link>
                                {/* <!-- <a className="dropdown-item" href="././Company/company_profile/resumes/resume.html">Employer
                                    Resume</a> --> */}
                                <Link className="dropdown-item"
                                    to="/post_jobs">Post
                                    A Job</Link>
                                <Link className="dropdown-item"
                                    to="/Manage_jobs">Manage
                                    Jobs</Link>
                                {/* <!-- <a className="dropdown-item"
                                    href="././Company/company_profile/transactions/transaction.html">Transactions</a>
                                <a className="dropdown-item" href="#">Browse Candidates</a> --> */}
                            </div>
                        </li>
                        <li className="nav-item dropdown position-relative d-inline-block">
                            <ul>
                            <a className="nav-link dropdown-toggle  font-weight-bold" href="#" id="a4" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style={{color:state.color}}>
                                PAGES
                            </a>
                                <div className="dropdown-menu dropdown-content  d-none position-absolute ml-4 bg-white rounded"
                                    aria-labelledby="navbarDropdown">
                                    {/* <!-- <li> <a className="dropdown-item " href="././Company/Pages/AboutUS/AboutUs.html">About
                                            us</a></li> --> */}
                                    <li> <Link className="dropdown-item "
                                            to="/companies">Companies</Link></li>
                                    {/* <!-- <li> <a className="dropdown-item" href="././Company/Pages/Job details/jobalert.html">Job
                                            Details</a></li>
                                    <li><a className="dropdown-item"
                                            href="././Company/Pages/Free Job Alerts/FreeJobAlert.html">Free Job
                                            Alerts</a>
                                    </li> --> */}
                                    <li className="dropdown-submenu position-relative">
                                        <a className="dropdown-item dropdown-toggle">Browse jobs</a>
                                        <ul
                                            className="dropdown-menu dropdown-content_1 d-none position-absolute  bg-white ">
                                            {/* <li><a className="dropdown-item"
                                                    href="././Company/Pages/Browse Job/Browse Job List/browsejoblist.html">Browse
                                                    Job List</a></li>
                                            <li><a className="dropdown-item"
                                                    href="././Company/Pages/Browse Job/Browse Job Grid/browsejobgrid.html">Browse
                                                    Job Grid</a></li> */}
                                            <li><Link className="dropdown-item"
                                                    to="/browsefilterlist">Browse
                                                    Filter List</Link></li>

                                            <li><Link className="dropdown-item"
                                                    to="/browsefiltergrid">Broswe
                                                    Filter Grid</Link></li>
                                        </ul>
                                    </li>
                                    <li className="dropdown-submenu position-relative">
                                        <a className="dropdown-item  dropdown-toggle">Jobs</a>
                                        <ul
                                            className="dropdown-menu dropdown-content_1 d-none position-absolute  bg-white ">
                                            <li><Link className="dropdown-item"
                                                    to="/alljobs">All
                                                    Jobs</Link>
                                            </li>
                                            <li><Link className="dropdown-item"
                                                    to="/companyjobs">Company
                                                    Jobs</Link></li>
                                            <li><Link className="dropdown-item"
                                                    to="/designationjobs">Designation
                                                    Jobs</Link></li>
                                            <li><Link className="dropdown-item"
                                                    to="/categoryjobs">Category
                                                    Jobs</Link></li>
                                            <li><Link className="dropdown-item"
                                                    to="/skilljobs">Skill
                                                    Jobs</Link>
                                            </li>
                                            <li><Link className="dropdown-item"
                                                    to="/locationaljobs">Locatinal
                                                    Jobs</Link></li>
                                        </ul>
                                    </li>
                                    {/* <!-- <li> <a className="dropdown-item" href="././Company/Pages/Portfolio/Portfolio.html">Portfolio</a></li> -->
                                    <!-- <li> <a className="dropdown-item" href="././Company/Pages/Error 404/Error.html">Error
                                            404</a></li>
                                    <li><a className="dropdown-item "
                                            href="././Company/Pages/ContactUs/ContactUs.html">Contact
                                            Us</a></li> --> */}
                                </div>
                            </ul>
                        </li>
                        {/* <!-- <li className="nav-item dropdown position-relative d-inline-block">
                            <a className="nav-link dropdown-toggle  font-weight-bold" href="#" id="a4" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                BLOGS
                            </a>
                            <div className="dropdown-menu dropdown-content  d-none position-absolute ml-4 bg-white rounded"
                                aria-labelledby="navbarDropdown">
                                <a className="dropdown-item" href="././Company/Blogs/Classic/Classic.html">Classic</a>
                                <a className="dropdown-item"
                                    href="././Company/Blogs/Classic Sidebar/Classic_sidebar.html">Classic
                                    Sidebar</a>
                                <a className="dropdown-item"
                                    href="././Company/Blogs/Detailed Grid/Detailed_Grid.html">Detailed
                                    Grid</a>
                                <a className="dropdown-item"
                                    href="././Company/Blogs/Detailed Grid Sidebar/Detailed_Grid_Sidebar.html">Detailed
                                    Grid
                                    Sidebar</a>
                                <a className="dropdown-item"
                                    href="././Company/Blogs/Left Image Sidebar/Left_Image_Sidebar.html">Left
                                    Image
                                    Sidebar</a>
                                <a className="dropdown-item" href="././Company/Blogs/Blog Details/Blog_Details.html">Blog
                                    Details</a>
                            </div>
                        </li> --> */}
                    </ul>
                    <ul className="navbar-nav ml-auto">
                        <li className="nav-item">
                            <Link className="nav-link   font-weight-bold" id="a5" to="/signup"><button type="button"
                                    className="btn  navbar-btn" data-toggle="modal" data-target="#SignUp"><i
                                        className="fas fa-user"></i> SIGNUP</button></Link>
                        </li>
                        <li className="nav-item">
                            <Link className="nav-link   font-weight-bold" id="a6" to="/signin"><button type="button"
                                    className="btn  navbar-btn" data-toggle="modal" data-target="#SignIn"><i
                                        className="fas fa-lock"></i> LOGIN</button></Link>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </div>
    )
}
export default Navbar