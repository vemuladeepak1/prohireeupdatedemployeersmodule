import React from 'react'
import { Link } from 'react-router-dom';
import EmployeeSideBar from './EmployeeSideBar';

export const COMPANY_PROFILE = () => {
    return (
        <div>
           


        <div className="container main_content">
        <div className="row">
            <div className="col-lg-3">
                    <EmployeeSideBar />
            </div>
            <div className="col-lg-9">
                <div className="wrapper">

                    <div className="content">
                        <div className="job-bx-title clearfix">
                            <h5 className=" pull-left text-uppercase cp">Company Profile</h5>
                            
                            <Link to="/" className="site-button right-arrow button-sm float-right"> back </Link>
                        </div>
                        <form action="#">
                            <div className="row m-b30">
                                <div className=" col-lg-12 col-md-12">
                                    <div className="form-group">
                                        <label> Company Name</label>
                                        <input type="text" className="form_control" placeholder="Enter Company Name" />
                                    </div>
                                </div>
                              
                            
                                <div className=" col-lg-6 col-md-6">
                                    <div className="form-group">
                                        <label> Website Link</label>
                                        <input type="text" className="form_control" placeholder="Website Link" />
                                    </div>
                                </div>
                                <div className=" col-lg-6 col-md-6">
                                    <div className="form-group">
                                        <label> Founded Date</label>
                                        <input type="text" className="form_control" placeholder="07/12/2021" />
                                    </div>
                                </div>
                               
                                <div className=" col-lg-6 col-md-6">
                                    <div className="form-group">
                                        <label> Category</label>
                                       <input type="text"  className="form_control" placeholder="Role" />
                                    </div>
                                </div>
                                <div className=" col-lg-6 col-md-6">
                                    <div className="form-group">
                                        <label> Country</label>
                                        <input type="text" className="form_control" placeholder="India" />
                                    </div>
                                </div>
                               
                                <div className=" col-lg-12 col-md-12">
                                    <div className="form-group">
                                        <label> Discription </label>
                                        <textarea className="form_control" cols="30" rows="5"></textarea>
                                    </div>
                                </div>

                            </div>
                        </form>

                        <h5 className="contact_info">Contact Information</h5>
                        <form action="#">
                            <div className="row m-b30">
                                <div className=" col-lg-6 col-md-6">
                                    <div className="form-group">
                                        <label> Phone</label>
                                        <input type="text" className="form_control" placeholder="+919876543210" />
                                    </div>
                                </div>
                                <div className=" col-lg-6 col-md-6">
                                    <div className="form-group">
                                        <label> Email</label>
                                        <input type="email" className="form_control" placeholder="Example@gmail.com" />
                                    </div>
                                </div>
                               
                                <div className=" col-lg-6 col-md-6">
                                    <div className="form-group">
                                        <label> Country</label>
                                        <select className="form_control mr-sm-2">
                                            <option selected>India</option>
                                           <option></option>
                                        </select>
                                    </div>
                                </div>
                                <div className=" col-lg-6 col-md-6">
                                    <div className="form-group">
                                        <label> State</label>
                                        <select className="form_control mr-sm-2">
                                            <option selected>Telangana</option>
                                            <option value="1">Tamilnadu</option>
                                            <option value="1">Arunachal Pradesh</option>
                                            <option value="1">Assam</option>
                                            <option value="1">Bihar</option>
                                            <option value="1">Chhattisghar</option>
                                            <option value="1">Goa</option>
                                            <option value="1">Gujarat</option>
                                            <option value="1">Haryana</option>
                                            <option value="1">Himachal Pradesh</option>
                                            <option value="1">Jammu Kashmir</option>
                                            <option value="1">Jharkhand</option>
                                            <option value="1">Karnataka</option>
                                            <option value="1">Kerala</option>
                                            <option value="1">Madhya Pradesh</option>
                                            <option value="1">Maharastra</option>
                                            <option value="1">Manipur</option>
                                            <option value="1">Meghalaya</option>
                                            <option value="1">Mizoram</option>
                                            <option value="1">Nagaland</option>
                                            <option value="1">Odisha</option>
                                            <option value="1">Punjab</option>
                                            <option value="1">Sikkim</option>
                                            <option value="1">Tripura</option>
                                            <option value="1">Uttar Pradesh</option>
                                            <option value="1">UttaraKhand</option>
                                            <option value="1">West Bengal</option>
                                            <option value="1">Andhra Pradesh</option>
                                            <option value="1">Rajasthan</option>

                                        </select>
                                    </div>
                                </div>
                                
                                
                                <div className=" col-lg-6 col-md-6">
                                    <div className="form-group">
                                        <label>Address</label>
                                        <input type="text" className="form_control" placeholder="Hydearbad" />
                                    </div>
                                </div>
                                <div className=" col-lg-6 col-md-6">
                                    <div className="form-group">
                                        <label> Pin-code</label>
                                        <input type="text" className="form_control" placeholder="505001" />
                                    </div>
                                </div>
                            </div>
                        </form>

                        <h5 className="contact_info">Social link</h5>
                        <form action="#">
                            <div className="row m-b30">
                                <div className=" col-lg-6 col-md-6">
                                    <div className="form-group">
                                        <label>Facebook</label>
                                        <input type="text" className="form_control" placeholder="Enter Your Facebook Id" / >
                                    </div>
                                </div>
                                <div className=" col-lg-6 col-md-6">
                                    <div className="form-group">
                                        <label>Twitter</label>
                                        <input type="email" className="form_control" placeholder="Enter Your twitter Id" />
                                    </div>
                                </div>
                                
                                <div className=" col-lg-6 col-md-6">
                                    <div className="form-group">
                                        <label>Google</label>
                                        <input type="text" className="form_control" placeholder="Enter Your Google Account" />
                                    </div>
                                </div>
                                <div className=" col-lg-6 col-md-6">
                                    <div className="form-group">
                                        <label>Linkedin</label>
                                        <input type="text" className="form_control"
                                            placeholder="Enter Your Linked in Profile" />
                                    </div>
                                </div>
                            </div>
                        </form>
                        <button className="update">Update</button>
                    </div>
                </div>
            </div>
        </div>
    </div>



        </div>
    )
}
export default COMPANY_PROFILE;
