import React from 'react'

 const MyResume = () => {
    return (
        <div>
            <div className="container-fluid my_profile">
        <div className="container">
            <div className="row">

                <div className="col-lg-9">
                    <div className="container">
                        <div className="row">
                            <div className="col-lg-2 ">
                                <div className="canditate-des"><a href="#"><img className="resume_img img-responsive" alt=""
                                            src="images/girl_avtar.png" /></a>
                                </div>
                            </div>

                            <div className="col-lg-10">
                                <h4 className="resume_title">
                                    John Doe <span className="correct_pencil"><i
                                            className="fas fa-pencil-alt pencil_icon"></i></span>

                                </h4>
                                <p className="resume_text">Freelance Senior PHP Developer at various agencies</p>
                                <a className="form-inline">
                                    <p className="location_resume_1"><span><i
                                                className="fas fa-map-marker-alt marker_icon"></i></span> <span
                                            className="location_resume">Banglore,India</span></p>
                                    <p><span><i className="fas fa-mobile-alt mobile_icon"></i></span> <span
                                            className="mobile_resume">+919876543210</span></p>
                                </a>
                                <a className="form-inline">
                                    <p className="location_resume_2"><span><i
                                                className="fas fa-map-marker-alt marker_icon"></i></span> <span
                                            className="location_resume">Fresher</span></p>
                                    <p><span><i className="fas fa-mobile-alt mobile_icon"></i></span> <span
                                            className="mobile_resume">perfextechnologies@gmail.com</span></p>
                                </a>

                                <div className="progress-box m-t10">
                                    <div className="progress-info">Profile Strength (Average)<span>70%</span>
                                    </div>
                                    <div className="progress">
                                        <div className="progress-bar bg-primary" role="progressbar">
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>

                <div className="col-lg-3">
                    <div className="pending_action_resume">
                        <h5 className="pending_action_heading">Pending Action</h5>
                        <p><span className=""><i className="fas fa-check check_icon"></i></span><span
                                className="pending_action_content">Verify Mobile Location</span></p>
                        <p><span className=""><i className="fas fa-check check_icon"></i></span><span
                                className="pending_action_content">Verify Mobile Location</span></p>
                        <p><span className=""><i className="fas fa-check check_icon"></i></span><span
                                className="pending_action_content">Verify Mobile Location</span></p>

                    </div>
                </div>




            </div>

        </div>
    </div>

    <div className="container">
        <div className="row">
            <div className="col-lg-3">
                <div className="sticky-top">
                    <p>
                        <button className="sidebar_button" data-toggle="collapse" href="#collapseExample" role="button"
                            aria-expanded="false" aria-controls="collapseExample" onclick="ezy()">
                            <i className="fa fa-bars text-white"></i>
                        </button>
                    </p>
                    <div id="collapseExample">
                        <div className="sidebar" id="sidebar">
                            <a href="#Resume_Headline"> Resume Headline</a>
                            <a href="#Key_skills"> Keyskills</a>
                            <a href="#Employment"> Employement</a>
                            <a href="#Education"> Eductaion</a>
                            <a href="#ITskills"> IT Skills</a>
                            <a href="#Project"> Project</a>
                            <a href="#ProfileSummary"> Profile Summary</a>
                            <a href="#Accomplishment"> Accomplishments</a>
                            <a href="#DesiredCareer"> Desired Career Profile</a>
                            <a href="#PersonalDetails"> Personal Details</a>
                            <a href="#AttachResume"> Attach Resume</a>
                        </div>
                    </div>
                </div>
            </div>
            <div className="col-lg-9">
                <div className="wrapper">

                    <div className="right_content">

                        <div className="content" id="Resume_Headline">
                            <div className="job-bx-title clearfix">
                                <h5 className=" pull-left text-capitalize cp">Resume Headline</h5>
                                <a href="#" className="site_button_resume  float-right"> <span><i
                                            className="fas fa-pencil-alt pencil_clearfix"></i></span> </a>
                            </div>
                            <p className="job_usa">Job board currently living in USA</p>
                        </div>

                        <div className="content" id="Key_skills">
                            <div className="job-bx-title clearfix">
                                <h5 className=" pull-left text-capitalize cp">Key Skills</h5>
                                <a href="#" className="site_button_resume  float-right"> <span><i
                                            className="fas fa-pencil-alt pencil_clearfix"></i></span> </a>
                            </div>

                            <form>
                                <div className="form-group mt-3">
                                    <label for="input" className="pl-3  btn_edit_1">Software Skills</label>
                                    <input type="text" className="form_control" id="tag-input1" />
                                    <label>Ex : <button className="js">java script</button>
                                        <button className="js">css</button>
                                        <button className="js">html</button>
                                        <button className="js">bootstrap</button>
                                        <button className="js">web designing</button>
                                        <button className="js">photoshop</button></label>
                                </div>
                            </form>


                        </div>

                        <div className="content" id="Employment">
                            <div className="job-bx-title clearfix">
                                <h5 className=" pull-left text-capitalize cp">Employment</h5>
                                <a href="#" className="site_button_resume  float-right"> <span><i
                                            className="fas fa-pencil-alt pencil_clearfix"></i></span> </a>
                            </div>
                            <h5 className="junior_edit">Junior Software Developer </h5>
                            <p className="job_usa">W3itexperts</p>
                            <p className="job_usa">Oct 2015 to Present (3 years 4 months)</p>
                            <p className="job_usa">Available to join in 1 Months</p>
                            <p className="job_usa">Junior Software Developer</p>
                        </div>

                        <div className="content" id="Education">
                            <div className="job-bx-title clearfix">
                                <h5 className=" pull-left text-capitalize cp">Education</h5>
                                <a href="#" className="site_button_resume  float-right"> <span><i
                                            className="fas fa-pencil-alt pencil_clearfix"></i></span> </a>
                            </div>
                            <p className="job_usa">Mention your employment details including your current and previous
                                company work
                                experience</p>
                            <div className="education_content_1">
                                <h5 className="education_heading">London - 12th</h5>
                                <p className="eductaion_year">2017</p>
                            </div>
                            <div className="education_content_2">
                                <h5 className="education_heading">London - 10th</h5>
                                <p className="eductaion_year">2015</p>
                            </div>
                            <a href="#">
                                <p className="education_sub">Add Doctorate/PhD</p>
                            </a>
                            <a href="#">
                                <p className="education_sub">Add Masters/Post-Graduation</p>
                            </a>
                            <a href="#">
                                <p className="education_sub">Add Graduation/Diploma</p>
                            </a>
                        </div>

                        <div className="content" id="ITskills">
                            <div className="job-bx-title clearfix">
                                <h5 className=" pull-left text-capitalize cp">IT Skills</h5>
                                <a href="#" className="site_button_resume  float-right"> <span><i
                                            className="fas fa-pencil-alt pencil_clearfix"></i></span> </a>
                            </div>
                            <p className="job_usa">Mention your employment details including your current and previous
                                company work
                                experience</p>
                            <div className="table_content">
                                <div className="table-responsive">
                                    <table className="table ">
                                        <thead>
                                            <tr>
                                                <th scope="col">Skills</th>
                                                <th scope="col">Version</th>
                                                <th scope="col">Last Used</th>
                                                <th scope="col">Experience</th>
                                                <th scope="col"></th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td scope="row" className="table_content_1">Bootstrap</td>
                                                <td className="table_content_1">3</td>
                                                <td className="table_content_1">2018</td>
                                                <td className="table_content_1">1 Year 5 Months</td>
                                                <td><i className="fas fa-pencil-alt pencil"></i></td>
                                            </tr>
                                            <tr className="table_row_content">
                                                <td scope="row" className="table_content_1">Bootstrap</td>
                                                <td className="table_content_1">4</td>
                                                <td className="table_content_1">2019</td>
                                                <td className="table_content_1">3 Year 5 Months</td>
                                                <td><i className="fas fa-pencil-alt pencil"></i></td>
                                            </tr>
                                            <tr>
                                                <td scope="row" className="table_content_1">Bootstrap</td>
                                                <td className="table_content_1">5</td>
                                                <td className="table_content_1">2020</td>
                                                <td className="table_content_1">2 Year 5 Months</td>
                                                <td><i className="fas fa-pencil-alt pencil"></i></td>
                                            </tr>
                                            <tr className="table_row_content">
                                                <td scope="row" className="table_content_1">HTML</td>
                                                <td className="table_content_1">5</td>
                                                <td className="table_content_1">2018</td>
                                                <td className="table_content_1">4 Year 5 Months</td>
                                                <td><i className="fas fa-pencil-alt pencil"></i></td>
                                            </tr>
                                            <tr>
                                                <td scope="row" className="table_content_1">CSS</td>
                                                <td className="table_content_1">3</td>
                                                <td className="table_content_1">2018</td>
                                                <td className="table_content_1">0 Year 5 Months</td>
                                                <td><i className="fas fa-pencil-alt pencil"></i></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>

                        <div className="content" id="Project">
                            <div className="job-bx-title clearfix">
                                <h5 className=" pull-left text-capitalize cp">Projects</h5>
                                <a href="#" className="site_button_resume  float-right"> <span><i
                                            className="fas fa-pencil-alt pencil_clearfix"></i></span> </a>
                            </div>
                            <h5 className="junior_edit">Job Board </h5>
                            <p className="job_usa">w3itexpert (Offsite)</p>
                            <p className="job_usa">Dec 2018 to Present (Full Time)</p>
                            <p className="job_usa">Job Board Template</p>
                        </div>

                        <div className="content" id="ProfileSummary">
                            <div className="job-bx-title clearfix">
                                <h5 className=" pull-left text-capitalize cp">Profile Summary</h5>
                                <a href="#" className="site_button_resume  float-right"><span><i
                                            className="fas fa-pencil-alt pencil_clearfix"></i></span> </a>
                            </div>
                            <p className="job_usa">Your Profile Summary should mention the highlights of your career and
                                education,
                                what
                                your professional interests are, and what kind of a career you are looking for. Write a
                                meaningful
                                summary of more than 50 characters.</p>
                        </div>

                        <div className="content" id="Accomplishment">
                            <div className="job-bx-title clearfix">
                                <h5 className=" pull-left text-capitalize cp">Accomplishment</h5>
                            </div>
                            <div className="content_sub">
                                <div className="content_sub_1">
                                    <div className="job-bx-title clearfix">
                                        <h5 className=" pull-left  cp_1">Online Profile</h5>
                                        <a href="#" className="site_button_resume  float-right"> <span><i
                                                    className="fas fa-pencil-alt pencil_clearfix"></i></span> </a>
                                    </div>
                                    <p className="job_usa">Add link to Online profiles (e.g. Linkedin, Facebook etc.).</p>
                                </div>
                                <div className="content_sub_1">
                                    <div className="job-bx-title clearfix">
                                        <h5 className=" pull-left  cp_1">Work Sample</h5>
                                        <a href="#" className="site_button_resume  float-right"> <span><i
                                                    className="fas fa-pencil-alt pencil_clearfix"></i></span> </a>
                                    </div>
                                    <p className="job_usa">Add link to your Projects (e.g. Github links etc.).</p>
                                </div>
                            </div>
                            <div className="content_sub">
                                <div className="job-bx-title clearfix">
                                    <h5 className=" pull-left  cp_1">White Paper / Research Publication</h5>
                                    <a href="#" className="site_button_resume  float-right"> <span><i
                                                className="fas fa-pencil-alt pencil_clearfix"></i></span> </a>
                                </div>
                                <p className="job_usa">Add links to your Online publications.</p>
                            </div>
                            <div className="content_sub">
                                <div className="job-bx-title clearfix">
                                    <h5 className=" pull-left  cp_1">Presentation</h5>
                                    <a href="#" className="site_button_resume  float-right"> <span><i
                                                className="fas fa-pencil-alt pencil_clearfix"></i></span> </a>
                                </div>
                                <p className="job_usa">Add links to your Online presentations (e.g. Slideshare presentation
                                    links
                                    etc.).
                                </p>
                            </div>
                            <div className="content_sub">
                                <div className="job-bx-title clearfix">
                                    <h5 className=" pull-left  cp_1">Patent</h5>
                                    <a href="#" className="site_button_resume  float-right"> <span><i
                                                className="fas fa-pencil-alt pencil_clearfix"></i></span> </a>
                                </div>
                                <p className="job_usa">Add details of Patents you have filed.</p>
                            </div>
                            <div className="content_sub">
                                <div className="job-bx-title clearfix">
                                    <h5 className=" pull-left  cp_1">Certification</h5>
                                    <a href="#" className="site_button_resume  float-right"> <span><i
                                                className="fas fa-pencil-alt pencil_clearfix"></i></span> </a>
                                </div>
                                <p className="job_usa">Add details of Certification you have filed.</p>
                            </div>
                        </div>

                        <div className="content" id="DesiredCareer">
                            <div className="job-bx-title clearfix">
                                <h5 className=" pull-left text-capitalize cp">Desired Career Profile</h5>
                                <a href="#" className="site_button_resume  float-right"> <span><i
                                            className="fas fa-pencil-alt pencil_clearfix"></i></span> </a>
                            </div>
                            <div className="container-fluid career_profile">
                                <div className="row">
                                    <div className="col-lg-6 col-md-6 career_profile_column">
                                        <div className="career_profile_content">
                                            <h5 className="industry">Industry</h5>
                                            <p className="it_employees">IT-Software/Software Services</p>
                                        </div>
                                        <div className="career_profile_content">
                                            <h5 className="industry">Role</h5>
                                            <p className="it_employees">Web Developer</p>
                                        </div>
                                        <div className="career_profile_content">
                                            <h5 className="industry">Employement Type</h5>
                                            <p className="it_employees">Full Time</p>
                                        </div>
                                        <div className="career_profile_content">
                                            <h5 className="industry">Available to Join </h5>
                                            <p className="it_employees">12th october</p>
                                        </div>
                                        <div className="career_profile_content">
                                            <h5 className="industry">Desired Location</h5>
                                            <p className="it_employees">Hyderabad</p>
                                        </div>
                                    </div>
                                    <div className="col-lg-6 col-md-6 career_profile_column">
                                        <div className="career_profile_content">
                                            <h5 className="industry">Functional Area</h5>
                                            <p className="it_employees">Design / Creative / User Experience</p>
                                        </div>
                                        <div className="career_profile_content">
                                            <h5 className="industry">Job Type</h5>
                                            <p className="it_employees">Permanent</p>
                                        </div>
                                        <div className="career_profile_content">
                                            <h5 className="industry">Desired Shift</h5>
                                            <p className="it_employees">Day</p>
                                        </div>
                                        <div className="career_profile_content">
                                            <h5 className="industry">Expected Salary</h5>
                                            <p className="it_employees">2 lakhs</p>
                                        </div>
                                        <div className="career_profile_content">
                                            <h5 className="industry">Desired Industry</h5>
                                            <p className="it_employees">TCS</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div className="content" id="PersonalDetails">
                            <div className="job-bx-title clearfix">
                                <h5 className=" pull-left text-capitalize cp">Personal Details</h5>
                                <a href="#" className="site_button_resume  float-right"> <span><i
                                            className="fas fa-pencil-alt pencil_clearfix"></i></span> </a>
                            </div>
                            <div className="container-fluid career_profile">
                                <div className="row">
                                    <div className="col-lg-6 col-md-6 career_profile_column">
                                        <div className="career_profile_content">
                                            <h5 className="industry">Date Of Birth</h5>
                                            <p className="it_employees">12/06/1995</p>
                                        </div>
                                        <div className="career_profile_content">
                                            <h5 className="industry">Gender</h5>
                                            <p className="it_employees">Female</p>
                                        </div>
                                        <div className="career_profile_content">
                                            <h5 className="industry">Marital Status</h5>
                                            <p className="it_employees">Sigle</p>
                                        </div>
                                        <div className="career_profile_content">
                                            <h5 className="industry">Passport Number </h5>
                                            <p className="it_employees">+ 123 456 7890</p>
                                        </div>
                                        <div className="career_profile_content">
                                            <h5 className="industry">Differently Abled</h5>
                                            <p className="it_employees">None</p>
                                        </div>
                                        <div className="career_profile_content">
                                            <h5 className="industry">Languages</h5>
                                            <p className="it_employees">English</p>
                                        </div>
                                    </div>
                                    <div className="col-lg-6 col-md-6 career_profile_column">
                                        <div className="career_profile_content">
                                            <h5 className="industry">Permanent Address</h5>
                                            <p className="it_employees">Add Permanent Address</p>
                                        </div>
                                        <div className="career_profile_content">
                                            <h5 className="industry">Area Pin Code</h5>
                                            <p className="it_employees">502021</p>
                                        </div>
                                        <div className="career_profile_content">
                                            <h5 className="industry">Home Town</h5>
                                            <p className="it_employees">Delhi</p>
                                        </div>
                                        <div className="career_profile_content">
                                            <h5 className="industry">Work permit of other country</h5>
                                            <p className="it_employees">USA</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div className="content" id="AttachResume">
                            <div className="job-bx-title clearfix">
                                <h5 className=" pull-left text-capitalize cp">Attach Resume</h5>
                            </div>
                            <p className="job_usa">Resume is the most important document recruiters look for. Recruiters
                                generally
                                do
                                not look at profiles without resumes.</p>
                            <form>
                                <div className="form-group">
                                    <label for="myfile" className="file_upload">Upload File</label>

                                    <input type="file" id="myfile" name="myfile" hidden />
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
        </div>
    )
}

export default MyResume