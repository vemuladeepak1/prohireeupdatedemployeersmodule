import React from 'react'
import { Link } from 'react-router-dom';
import EmployeeSideBar from './EmployeeSideBar';
export const POST_A_JOB = () => {
    return (
        <div>
            

        <div className="container main_content">
        <div className="row">
            <div className="col-lg-3">
                    <EmployeeSideBar />
            </div>
            <div className="col-lg-9">
                <div className="wrapper">


                    <div className="content">

                        <div className="job-bx-title clearfix">
                            <h5 className=" pull-left text-uppercase cp">Post A Job</h5>
                            <Link to="/" className="site-button right-arrow button-sm float-right"> back </Link>
                        </div>

                        <form action="#">
                            <div className="row m-b30">
                                <div className=" col-lg-6 col-md-6">
                                    <div className="form-group">
                                        <label> Job Title</label>
                                        <input type="text" className="form_control"
                                            placeholder="Enter Your Designation Here" />
                                    </div>
                                </div>
                                <div className=" col-lg-6 col-md-6">
                                    <div className="form-group">
                                        <label> Positions available</label>
                                        <input type="text" className="form_control"
                                        placeholder="No. of positions available" />
                                    </div>
                                </div>

                                
                                <div className=" col-lg-12 col-md-12">
                                    <div className="form-group">
                                        <label>Job Discription</label>
                                        <input type="text" className="form_control" />
                                    </div>
                                </div>

                              
                                <div className=" col-lg-6 col-md-6">
                                    <div className="form-group">
                                        <label>Job Type</label>
                                        <select className="form_control mr-sm-2">
                                            <option selected>Full Time</option>
                                            <option value="1">Part Time</option>
                                            <option >Freelancer</option>
                                        </select>
                                    </div>
                                </div>
                                <div className=" col-lg-6 col-md-6">
                                    <div className="form-group">
                                        <label>Experience</label>
                                        <input type="text" className="form_control"
                                        placeholder="Years of Experience" />
                                    </div>
                                </div>

                               
                                <div className=" col-lg-12 col-md-12">
                                    <div className="form-group">
                                        <label>Maximum salary</label>
                                        <input type="text" className="form_control" placeholder="0 INR" />
                                    </div>
                                </div>


                                
                                <div className=" col-lg-6 col-md-6">
                                    <div className="form-group">
                                        <label>Region</label>
                                        <select className="form_control mr-sm-2">
                                            <option selected>India</option>
                                           
                                            <option ></option>
                                        </select>
                                    </div>
                                </div>
                                <div className=" col-lg-6 col-md-6">
                                    <div className="form-group">
                                        <label>Current Location</label>
                                        <input type="text" className="form_control" placeholder="India" />
                                    </div>
                                </div>



                            </div>
                        </form>
                        <button className="update_pj">Post a Job</button>
                    </div>

                </div>
            </div>
        </div>
    </div>



        </div>
    )
}
export default POST_A_JOB;