import React from 'react'
import { Link } from 'react-router-dom';
import EmployeeSideBar from './EmployeeSideBar';

export const Manage_Jobs = () => {
    return (
        <div>
            

        <div className="container main_content">
        <div className="row">
            <div className="col-lg-3">
                    <EmployeeSideBar />
            </div>
            <div className="col-lg-9">
                <div className="wrapper">





                 

                    <div className="content">

                        <div className="job-bx-title clearfix">
                            <h5 className=" pull-left text-uppercase cp">Manage Jobs</h5>
                            <a href="#" className=" float-right custom_class">
                                <span className="sort">Sort By Freshness</span>
                                <select name="#" id="#" className="custom_button">
                                    <option>All</option>
                                 
                                    <option>Read</option>
                                    <option>Unread</option>
                                   
                                </select>
                            </a>
                        </div>

                        <div className="table-responsive">
                            <table className="table table-striped">
                                <thead className="table_head">
                                    <tr>
                                        <th scope="col">


                                        </th>
                                        <th scope="col">JobTitle</th>
                                        <th scope="col">Application</th>
                                        <th scope="col">Status</th>
                                        <th scope="col">Edit</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>
                                            <form action="#">
                                                <div className="form-check">
                                                    <input className="form-check-input_1" type="checkbox" value=""
                                                        id="defaultCheck1" />
                                                </div>
                                            </form>
                                        </td>
                                        <td>
                                            <a href="#" className="heading_a_table">Social Media Expert</a>


                                        </td>
                                        <td>
                                            <p className="appications"><Link to="/Applications">Applications</Link></p>
                                        </td>
                                        <td>
                                            <p className="pending">Pending</p>
                                        </td>
                                        <td>
                                            <div className="form-inline">
                                                <div className="content_del_eye">
                                                    <a href="#"> <i className="fas fa-eye eye"></i></a>
                                                    <Link to="/post_jobs"><i className="fas fa-pencil-alt eye"></i></Link>
                                                    <a href="#"><i className="far fa-trash-alt del"></i></a>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                  
                                    <tr>
                                        <td>
                                            <form action="#">
                                                <div className="form-check">
                                                    <input className="form-check-input_1" type="checkbox" value=""
                                                        id="defaultCheck1" />
                                                </div>
                                            </form>
                                        </td>
                                        <td>
                                            <a href="#" className="heading_a_table">Social Media Expert</a>


                                        </td>
                                        <td>
                                            <p className="appications"><Link to="/Applications">Applications</Link></p>
                                        </td>
                                        <td>
                                            <p className="pending">Expired</p>
                                        </td>
                                        <td>
                                            <div className="form-inline">
                                                <div className="content_del_eye">
                                                    <a href="#"> <i className="fas fa-eye eye"></i></a>
                                                    <Link to="/post_jobs"><i className="fas fa-pencil-alt eye"></i></Link>
                                                    <a href="#"><i className="far fa-trash-alt del"></i></a>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                   
                                    <tr>
                                        <td>
                                            <form action="#">
                                                <div className="form-check">
                                                    <input className="form-check-input_1" type="checkbox" value=""
                                                        id="defaultCheck1" />
                                                </div>
                                            </form>
                                        </td>
                                        <td>
                                            <a href="#" className="heading_a_table">Social Media Expert</a>
 

                                        </td>
                                        <td>
                                            <p className="appications"><Link to="/Applications">Applications</Link></p>
                                        </td>
                                        <td>
                                            <p className="act">Active</p>
                                        </td>
                                        <td>
                                            <div className="form-inline">
                                                <div className="content_del_eye">
                                                    <a href="#"> <i className="fas fa-eye eye"></i></a>
                                                    <Link to="/post_jobs"><i className="fas fa-pencil-alt eye"></i></Link>
                                                    <a href="#"><i className="far fa-trash-alt del"></i></a>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                  

                                    <tr>
                                        <td>
                                            <form action="#">
                                                <div className="form-check">
                                                    <input className="form-check-input_1" type="checkbox" value=""
                                                        id="defaultCheck1"/>
                                                </div>
                                            </form>
                                        </td>
                                        <td>
                                            <a href="#" className="heading_a_table">Social Media Expert</a>


                                        </td>
                                        <td>
                                            <p className="appications"><Link to="/Applications">Applications</Link></p>
                                        </td>
                                        <td>
                                            <p className="pending">Pending</p>
                                        </td>
                                        <td>
                                            <div className="form-inline">
                                                <div className="content_del_eye">
                                                    <a href="#"> <i className="fas fa-eye eye"></i></a>
                                                    <Link to="/post_jobs"><i className="fas fa-pencil-alt eye"></i></Link>
                                                    <a href="#"><i className="far fa-trash-alt del"></i></a>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                    

                                    <tr>
                                        <td>
                                            <form action="#">
                                                <div className="form-check">
                                                    <input className="form-check-input_1" type="checkbox" value=""
                                                        id="defaultCheck1" />
                                                </div>
                                            </form>
                                        </td>
                                        <td>
                                            <a href="#" className="heading_a_table">Social Media Expert</a>


                                        </td>
                                        <td>
                                            <p className="appications"><Link to="/Applications">Applications</Link></p>
                                        </td>
                                        <td>
                                            <p className="pending">Pending</p>
                                        </td>
                                        <td>
                                            <div className="form-inline">
                                                <div className="content_del_eye">
                                                    <a href="#"> <i className="fas fa-eye eye"></i></a>
                                                    <Link to="/post_jobs"><i className="fas fa-pencil-alt eye"></i></Link>
                                                    <a href="#"><i className="far fa-trash-alt del"></i></a>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                   
                                    <tr>
                                        <td>
                                            <form action="#">
                                                <div className="form-check">
                                                    <input className="form-check-input_1" type="checkbox" value=""
                                                        id="defaultCheck1" />
                                                </div>
                                            </form>
                                        </td>
                                        <td>
                                            <a href="#" className="heading_a_table">Social Media Expert</a>


                                        </td>
                                        <td>
                                            <p className="appications"><Link to="/Applications">Applications</Link></p>
                                        </td>
                                        <td>
                                            <p className="pending">Pending</p>
                                        </td>
                                        <td>
                                            <div className="form-inline">
                                                <div className="content_del_eye">
                                                    <a href="#"> <i className="fas fa-eye eye"></i></a>
                                                    <Link to="/post_jobs"><i className="fas fa-pencil-alt eye"></i></Link>
                                                    <a href="#"><i className="far fa-trash-alt del"></i></a>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                    

                                    <tr>
                                        <td>
                                            <form action="#">
                                                <div className="form-check">
                                                    <input className="form-check-input_1" type="checkbox" value=""
                                                        id="defaultCheck1" />
                                                </div>
                                            </form>
                                        </td>
                                        <td>
                                            <a href="#" className="heading_a_table">Social Media Expert</a>


                                        </td>
                                        <td>
                                            <p className="appications"><Link to="/Applications">Applications</Link></p>
                                        </td>
                                        <td>
                                            <p className="pending">Pending</p>
                                        </td>
                                        <td>
                                            <div className="form-inline">
                                                <div className="content_del_eye">
                                                    <a href="#"> <i className="fas fa-eye eye"></i></a>
                                                    <Link to="/post_jobs"><i className="fas fa-pencil-alt eye"></i></Link>
                                                    <a href="#"><i className="far fa-trash-alt del"></i></a>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                    
                                    <tr>
                                        <td>
                                            <form action="#">
                                                <div className="form-check">
                                                    <input className="form-check-input_1" type="checkbox" value=""
                                                        id="defaultCheck1" />
                                                </div>
                                            </form>
                                        </td>
                                        <td>
                                            <a href="#" className="heading_a_table">Social Media Expert</a>
      

                                        </td>
                                        <td>
                                            <p className="appications"><Link to="/Applications">Applications</Link></p>
                                        </td>
                                        <td>
                                            <p className="pending">Pending</p>
                                        </td>
                                        <td>
                                            <div className="form-inline">
                                                <div className="content_del_eye">
                                                    <a href="#"> <i className="fas fa-eye eye"></i></a>
                                                    <Link to="/post_jobs"><i className="fas fa-pencil-alt eye"></i></Link>
                                                    <a href="#"><i className="far fa-trash-alt del"></i></a>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                    

                                    <tr>
                                        <td>
                                            <form action="#">
                                                <div className="form-check">
                                                    <input className="form-check-input_1" type="checkbox" value=""
                                                        id="defaultCheck1"/>
                                                </div>
                                            </form>
                                        </td>
                                        <td>
                                            <a href="#" className="heading_a_table">Social Media Expert</a>

                                            
                                        </td>
                                        <td>
                                            <p className="appications"><Link to="/Applications">Applications</Link></p>
                                        </td>
                                        <td>
                                            <p className="pending">Pending</p>
                                        </td>
                                        <td>
                                            <div className="form-inline">
                                                <div className="content_del_eye">
                                                    <a href="#"> <i className="fas fa-eye eye"></i></a>
                                                    <Link to="/post_jobs"><i className="fas fa-pencil-alt eye"></i></Link>
                                                    <a href="#"><i className="far fa-trash-alt del"></i></a>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                   

                                    <tr>
                                        <td>
                                            <form action="#">
                                                <div className="form-check">
                                                    <input className="form-check-input_1" type="checkbox" value=""
                                                        id="defaultCheck1"/>
                                                </div>
                                            </form>
                                        </td>
                                        <td>
                                            <a href="#" className="heading_a_table">Social Media Expert</a>


                                        </td>
                                        <td>
                                            <p className="appications"><Link to="/Applications">Applications</Link></p>
                                        </td>
                                        <td>
                                            <p className="pending">Pending</p>
                                        </td>
                                        <td>
                                            <div className="form-inline">
                                                <div className="content_del_eye">
                                                    <a href="#"> <i className="fas fa-eye eye"></i></a>
                                                    <Link to="/post_jobs"><i className="fas fa-pencil-alt eye"></i></Link>
                                                    <a href="#"><i className="far fa-trash-alt del"></i></a>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                            <div className="paging">
                                <ul className="pagination">
                                    <li className="page-item disabled">
                                        <a className="page-link" href="#" tabindex="-1">Previous</a>
                                    </li>
                                    <li className="page-item"><a className="page-link   active" href="#">1</a></li>
                                    <li className="page-item">
                                        <a className="page-link" href="#">2 <span className="sr-only">(current)</span></a>
                                    </li>
                                    <li className="page-item"><a className="page-link" href="#">3</a></li>
                                    <li className="page-item">
                                        <a className="page-link" href="#">Next</a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>





        </div>
    )
}
export default Manage_Jobs;