
import React from 'react'
import { Link } from 'react-router-dom'
import Sidebar from './Sidebar'
const MyProfile = () => {
    return (
        <div className="container main_content">
        <div className="row">
            <div className="col-lg-3">
                <Sidebar />
            </div>
            <div className="col-lg-9">
                <div className="wrapper">
                    <div className="content">
                        <div className="job-bx-title clearfix">
                            <h5 className=" pull-left text-uppercase cp">Basic Information</h5>
                            <Link to="/" className="site-button right-arrow button-sm float-right"> back </Link>
                        </div>
                        <form action="#">
                            <div className="row m-b30">
                                <div className=" col-lg-6 col-md-6">
                                    <div className="form-group">
                                        <label>Your Name:</label>
                                        <input type="text" className="form_control" placeholder="Enter Your Name" />
                                    </div>
                                </div>
                                <div className=" col-lg-6 col-md-6">
                                    <div className="form-group">
                                        <label>Preffered Location:</label>
                                        <input type="text" className="form_control" placeholder="Web Developer" />
                                    </div>
                                </div>
                                {/* <!-- second --> */}
                                <div className=" col-lg-6 col-md-6">
                                    <div className="form-group">
                                        <label for="input">Languages</label>
                                        <input type="text" className="form_control" id="tag-input1"
                                            placeholder="Enter Languages You Know" />
                                    </div>
                                </div>
                                <div className=" col-lg-6 col-md-6">
                                    <div className="form-group">
                                        <label>Age:</label>
                                        <input type="text" className="form_control" placeholder="25 years" />
                                    </div>
                                </div>
                                {/* <!-- third --> */}
                                <div className=" col-lg-6 col-md-6">
                                    <div className="form-group">
                                        <label>Current Salary:</label>
                                        <input type="text" className="form_control" placeholder="200000" />
                                    </div>
                                </div>
                                <div className=" col-lg-6 col-md-6">
                                    <div className="form-group">
                                        <label>Expected Salary:</label>
                                        <input type="text" className="form_control" placeholder="600000" />
                                    </div>
                                </div>
                                {/* <!-- fourth --> */}
                                <div className=" col-lg-12 col-md-12">
                                    <div className="form-group">
                                        <label> Description:</label>
                                        <textarea className="form_control" cols="30" rows="5"></textarea>
                                    </div>
                                </div>
                            </div>
                        </form>
                        <h5 className="contact_info">Contact Information</h5>
                        <form action="#">
                            <div className="row m-b30">
                                <div className=" col-lg-6 col-md-6">
                                    <div className="form-group">
                                        <label> Phone</label>
                                        <input type="text" className="form_control" placeholder="+919876543210" />
                                    </div>
                                </div>
                                <div className=" col-lg-6 col-md-6">
                                    <div className="form-group">
                                        <label> Email</label>
                                        <input type="email" className="form_control" placeholder="Example@gmail.com" />
                                    </div>
                                </div>
                                {/* <!-- second --> */}
                                <div className=" col-lg-6 col-md-6">
                                    <div className="form-group">
                                        <label> Country</label>
                                        <select className="form_control mr-sm-2">
                                            <option selected></option>
                                            <option>India</option>
                                        </select>
                                    </div>
                                </div>
                                <div className=" col-lg-6 col-md-6">
                                    <div className="form-group">
                                        <label> State</label>
                                        <select className="form_control mr-sm-2">
                                            <option selected>Telangana</option>
                                            <option value="1">Tamilnadu</option>
                                            <option value="1">Arunachal Pradesh</option>
                                            <option value="1">Assam</option>
                                            <option value="1">Bihar</option>
                                            <option value="1">Chhattisghar</option>
                                            <option value="1">Goa</option>
                                            <option value="1">Gujarat</option>
                                            <option value="1">Haryana</option>
                                            <option value="1">Himachal Pradesh</option>
                                            <option value="1">Jammu Kashmir</option>
                                            <option value="1">Jharkhand</option>
                                            <option value="1">Karnataka</option>
                                            <option value="1">Kerala</option>
                                            <option value="1">Madhya Pradesh</option>
                                            <option value="1">Maharastra</option>
                                            <option value="1">Manipur</option>
                                            <option value="1">Meghalaya</option>
                                            <option value="1">Mizoram</option>
                                            <option value="1">Nagaland</option>
                                            <option value="1">Odisha</option>
                                            <option value="1">Punjab</option>
                                            <option value="1">Sikkim</option>
                                            <option value="1">Tripura</option>
                                            <option value="1">Uttar Pradesh</option>
                                            <option value="1">UttaraKhand</option>
                                            <option value="1">West Bengal</option>
                                            <option value="1">Andhra Pradesh</option>
                                            <option value="1">Rajasthan</option>
                                        </select>
                                    </div>
                                </div>
                                {/* <!-- third --> */}
                                <div className=" col-lg-6 col-md-6">
                                    <div className="form-group">
                                        <label>Address</label>
                                        <input type="text" className="form_control" placeholder="Hydearbad" />
                                    </div>
                                </div>
                                <div className=" col-lg-6 col-md-6">
                                    <div className="form-group">
                                        <label> Pin-Code</label>
                                        <input type="text" className="form_control" placeholder="505001" />
                                    </div>
                                </div>
                            </div>
                        </form>
                        <button className="update">Save</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    )
}
export default MyProfile